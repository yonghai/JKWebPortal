package jk.o1office.dao;

import jk.o1office.domin.Complain;

public interface ComplainDao {

	boolean save(Complain complain);

}
