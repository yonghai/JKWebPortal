package jk.o1office.excetion;

public class DuserReisterException extends Exception {

}
