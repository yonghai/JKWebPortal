package jk.o1office.excetion;

public class TelException extends Exception {
	
	public TelException() {
	}
}
