package jk.o1office.excetion;

public class TokenException extends Exception {

}
