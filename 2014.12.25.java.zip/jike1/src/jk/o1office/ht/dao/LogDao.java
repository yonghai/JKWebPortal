package jk.o1office.ht.dao;

import jk.o1office.ht.domin.LoginInfo;

public interface LogDao {

	void saveLog(LoginInfo loginInfo);

}
