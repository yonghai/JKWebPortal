package jk.o1office.ht.exception;

public class NullException extends Exception {
	
}
