package jk.o1office.ht.exception;

public class NumberException extends Exception {

}
