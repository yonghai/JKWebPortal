package jk.o1office.mail;
/** 
 * @author 作者: 
 * @version 创建时间：2014-2-19 下午1:59:59 
 * @description 说明：
 */
public class MailException extends Exception{
	public MailException(String str){
		super(str);
	}

}
