package jk.o1office.service;

public interface Cmplainservice {

}
