package jk.o1office.service;

public interface InitService {

	String init(String token) throws Exception;

}
