package jk.o1office.dao;

import java.util.List;

import jk.o1office.domin.GoodsCategory;

public interface GoodsCategoryDao {

	List<GoodsCategory> getGoodsCategories(int id);

}
