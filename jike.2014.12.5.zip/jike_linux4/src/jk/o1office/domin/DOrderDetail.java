package jk.o1office.domin;

public class DOrderDetail {
	private int product_id; 
	private String product_name;
	private int product_number;
	private String product_price;
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int productId) {
		product_id = productId;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String productName) {
		product_name = productName;
	}
	public int getProduct_number() {
		return product_number;
	}
	public void setProduct_number(int productNunmber) {
		product_number = productNunmber;
	}
	public String getProduct_price() {
		return product_price;
	}
	public void setProduct_price(String productPrice) {
		product_price = productPrice;
	}
}
