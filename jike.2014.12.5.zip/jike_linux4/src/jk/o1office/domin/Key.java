package jk.o1office.domin;

public class Key {
	private String content;
	private int count;

	private int id;

	private int userid;

	public String getContent() {
		return content;
	}
	public int getCount() {
		return count;
	}

	public int getId() {
		return id;
	}

	public int getUserid() {
		return userid;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}
}
