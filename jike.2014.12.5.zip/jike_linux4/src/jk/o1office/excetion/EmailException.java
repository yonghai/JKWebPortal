package jk.o1office.excetion;

public class EmailException extends Exception {
	public EmailException() {
	}
}
