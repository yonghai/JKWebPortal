package jk.o1office.excetion;

public class IDCardException extends Exception {

}
