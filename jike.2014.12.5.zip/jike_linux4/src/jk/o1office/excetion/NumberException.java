package jk.o1office.excetion;

public class NumberException extends Exception {
	public NumberException() {
	}
}	

