package jk.o1office.finals;

public class Constant {
	//每页显示的条数
	public static int PAGESIZE = 10;
	
	public static String IMGPATH = "interface.jikesoon.com/jk1/";
}
