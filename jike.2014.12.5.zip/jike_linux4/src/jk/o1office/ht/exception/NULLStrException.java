package jk.o1office.ht.exception;

public class NULLStrException extends Exception {

}
