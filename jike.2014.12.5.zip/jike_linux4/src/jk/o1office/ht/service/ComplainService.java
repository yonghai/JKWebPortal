package jk.o1office.ht.service;

public interface ComplainService {

	String getComplain() throws Exception;

}
