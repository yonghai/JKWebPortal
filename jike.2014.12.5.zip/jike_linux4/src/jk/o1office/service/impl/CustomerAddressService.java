package jk.o1office.service.impl;

public interface CustomerAddressService {

	int getAreaID(int addressid);

	Integer[] getAddressIds(int areaid);

}
